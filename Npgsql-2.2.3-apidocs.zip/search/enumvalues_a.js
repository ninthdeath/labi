var searchData=
[
  ['schemaname',['SchemaName',['../class_npgsql_1_1_npgsql_error.html#a4839b846e4a8c8f3e44a461e393991e7a2abfe9f1267a1defef673c59ddd79054',1,'Npgsql::NpgsqlError']]],
  ['severity',['Severity',['../class_npgsql_1_1_npgsql_error.html#a4839b846e4a8c8f3e44a461e393991e7a007cc9547ae8884ad597cd92ba505422',1,'Npgsql::NpgsqlError']]]
];
