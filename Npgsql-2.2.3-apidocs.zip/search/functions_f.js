var searchData=
[
  ['save',['Save',['../class_npgsql_1_1_npgsql_transaction.html#a56cb692b6861fbb766aac1a86776d56c',1,'Npgsql::NpgsqlTransaction']]],
  ['sendclosedevent',['SendClosedEvent',['../class_npgsql_1_1_npgsql_data_reader.html#a942435327f78fbd9ccaf201acd32aeff',1,'Npgsql::NpgsqlDataReader']]],
  ['setparameter',['SetParameter',['../class_npgsql_1_1_npgsql_parameter_collection.html#aabfb44696c16308c12aecc1e4724eecc',1,'Npgsql.NpgsqlParameterCollection.SetParameter(string parameterName, DbParameter value)'],['../class_npgsql_1_1_npgsql_parameter_collection.html#a3242d150b25887e772950ca42a299eb5',1,'Npgsql.NpgsqlParameterCollection.SetParameter(int index, DbParameter value)']]],
  ['setrowupdatinghandler',['SetRowUpdatingHandler',['../class_npgsql_1_1_npgsql_command_builder.html#a57be3a179a38b834c44609e47cc6e39f',1,'Npgsql::NpgsqlCommandBuilder']]],
  ['start',['Start',['../class_npgsql_1_1_npgsql_copy_in.html#ad41beaa25d254474251a545a48771576',1,'Npgsql.NpgsqlCopyIn.Start()'],['../class_npgsql_1_1_npgsql_copy_out.html#aeca1fdd6e197e0e43571cbf1e96d176e',1,'Npgsql.NpgsqlCopyOut.Start()']]]
];
