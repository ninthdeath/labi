var searchData=
[
  ['readerclosed',['ReaderClosed',['../class_npgsql_1_1_npgsql_data_reader.html#a5385675d4960ddd2267d2cdea66f86b8',1,'Npgsql::NpgsqlDataReader']]],
  ['rowupdated',['RowUpdated',['../class_npgsql_1_1_npgsql_data_adapter.html#a7afcb185428ed42c66970c411857901a',1,'Npgsql::NpgsqlDataAdapter']]],
  ['rowupdating',['RowUpdating',['../class_npgsql_1_1_npgsql_data_adapter.html#a7ca228566b6152ef3740fca283a2c9fc',1,'Npgsql::NpgsqlDataAdapter']]]
];
