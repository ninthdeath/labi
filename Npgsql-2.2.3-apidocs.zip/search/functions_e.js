var searchData=
[
  ['remove',['Remove',['../class_npgsql_1_1_npgsql_parameter_collection.html#a22c4b6576a840c28578081d30842338d',1,'Npgsql.NpgsqlParameterCollection.Remove(string parameterName)'],['../class_npgsql_1_1_npgsql_parameter_collection.html#a26ff6559f35d00666012c699a01c4784',1,'Npgsql.NpgsqlParameterCollection.Remove(object oValue)'],['../class_npgsql_1_1_npgsql_parameter_collection.html#a35d9b25fb09a963af35fa3c6346483d3',1,'Npgsql.NpgsqlParameterCollection.Remove(NpgsqlParameter item)']]],
  ['removeat',['RemoveAt',['../class_npgsql_1_1_npgsql_parameter_collection.html#a5e377641a42679863188a639bdeead35',1,'Npgsql.NpgsqlParameterCollection.RemoveAt(string parameterName)'],['../class_npgsql_1_1_npgsql_parameter_collection.html#a1b1cfc05a179ecad0a70f843814842c8',1,'Npgsql.NpgsqlParameterCollection.RemoveAt(int index)']]],
  ['resetdbtype',['ResetDbType',['../class_npgsql_1_1_npgsql_parameter.html#ab657a5fcc12b2a1ca865527c645fcb65',1,'Npgsql::NpgsqlParameter']]],
  ['rollback',['Rollback',['../class_npgsql_1_1_npgsql_transaction.html#a0eb057ac5e4b9b48c2ccbd2ce951c2a2',1,'Npgsql.NpgsqlTransaction.Rollback()'],['../class_npgsql_1_1_npgsql_transaction.html#a6b1af30f8241e603d7ecd6a51291bf97',1,'Npgsql.NpgsqlTransaction.Rollback(String savePointName)']]]
];
