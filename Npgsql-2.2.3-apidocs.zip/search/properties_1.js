var searchData=
[
  ['backendprotocolversion',['BackendProtocolVersion',['../class_npgsql_1_1_npgsql_connection.html#a192b3157c6985bbc09cefdbe26cf14eb',1,'Npgsql::NpgsqlConnection']]],
  ['basemessage',['BaseMessage',['../class_npgsql_1_1_npgsql_exception.html#ac6d0af199664a9444075c958c89c2c80',1,'Npgsql::NpgsqlException']]],
  ['buffersize',['BufferSize',['../class_npgsql_1_1_npgsql_copy_serializer.html#a6e1f68291558a5a642f7fb0863464368',1,'Npgsql::NpgsqlCopySerializer']]]
];
