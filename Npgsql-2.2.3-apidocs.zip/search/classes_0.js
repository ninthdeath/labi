var searchData=
[
  ['bytestreamer',['ByteStreamer',['../class_npgsql_1_1_row_reader_1_1_byte_streamer.html',1,'Npgsql::RowReader']]]
];
