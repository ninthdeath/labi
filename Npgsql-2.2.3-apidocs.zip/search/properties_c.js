var searchData=
[
  ['quoteprefix',['QuotePrefix',['../class_npgsql_1_1_npgsql_command_builder.html#ab2418149cc58904d786d18f371ddcd9e',1,'Npgsql::NpgsqlCommandBuilder']]],
  ['quotesuffix',['QuoteSuffix',['../class_npgsql_1_1_npgsql_command_builder.html#abd6f1fd1159bf65e2236d5343d5903fb',1,'Npgsql::NpgsqlCommandBuilder']]]
];
