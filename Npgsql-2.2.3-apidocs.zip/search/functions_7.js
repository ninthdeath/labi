var searchData=
[
  ['hasordinal',['HasOrdinal',['../class_npgsql_1_1_npgsql_data_reader.html#a003ca85adf3f9f3831a3a5e4f9ea96e3',1,'Npgsql::NpgsqlDataReader']]]
];
