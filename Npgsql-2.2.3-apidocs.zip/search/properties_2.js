var searchData=
[
  ['code',['Code',['../class_npgsql_1_1_npgsql_error.html#a75194a616fcc502a00b00a6fba3302db',1,'Npgsql.NpgsqlError.Code()'],['../class_npgsql_1_1_npgsql_exception.html#a91ee663d0ccf7dda0a4b29f16a77585b',1,'Npgsql.NpgsqlException.Code()']]],
  ['collection',['Collection',['../class_npgsql_1_1_npgsql_parameter.html#a501c7ef77b4b9ff7873b5c0148e7d444',1,'Npgsql::NpgsqlParameter']]],
  ['columnname',['ColumnName',['../class_npgsql_1_1_npgsql_error.html#afb6fef5b9cfa103128f11f809a711e65',1,'Npgsql.NpgsqlError.ColumnName()'],['../class_npgsql_1_1_npgsql_exception.html#a6deab05653c401c9b5be400dc6d39bfb',1,'Npgsql.NpgsqlException.ColumnName()']]],
  ['commandtext',['CommandText',['../class_npgsql_1_1_npgsql_command.html#af607863133951eafbc99d70eb591386b',1,'Npgsql::NpgsqlCommand']]],
  ['commandtimeout',['CommandTimeout',['../class_npgsql_1_1_npgsql_command.html#a28ff48a73b032ca14d7bc75d6a03b386',1,'Npgsql.NpgsqlCommand.CommandTimeout()'],['../class_npgsql_1_1_npgsql_connection.html#a07e67a91bace52f09ff1b59e0dbde679',1,'Npgsql.NpgsqlConnection.CommandTimeout()'],['../class_npgsql_1_1_npgsql_connection_string_builder.html#a326fbdb1707562b54b7c3d9afd4d5d55',1,'Npgsql.NpgsqlConnectionStringBuilder.CommandTimeout()']]],
  ['commandtype',['CommandType',['../class_npgsql_1_1_npgsql_command.html#a9f82ec184a37609737eb04c3d2c68100',1,'Npgsql::NpgsqlCommand']]],
  ['compatible',['Compatible',['../class_npgsql_1_1_npgsql_connection_string_builder.html#aea820044c439be37276f9c7297c8d13e',1,'Npgsql::NpgsqlConnectionStringBuilder']]],
  ['connection',['Connection',['../class_npgsql_1_1_npgsql_command.html#aeb5284f879dbc0f406154f5149ee679c',1,'Npgsql.NpgsqlCommand.Connection()'],['../class_npgsql_1_1_npgsql_transaction.html#ad1fa4ccf64386b47561145068f5fe938',1,'Npgsql.NpgsqlTransaction.Connection()']]],
  ['connectionlifetime',['ConnectionLifeTime',['../class_npgsql_1_1_npgsql_connection.html#a2c121fce4bb566172f2f5bb9cc54ad70',1,'Npgsql.NpgsqlConnection.ConnectionLifeTime()'],['../class_npgsql_1_1_npgsql_connection_string_builder.html#a7e8080f2190490744174e48cd9c545d9',1,'Npgsql.NpgsqlConnectionStringBuilder.ConnectionLifeTime()']]],
  ['connectionstring',['ConnectionString',['../class_npgsql_1_1_npgsql_connection.html#a0fb7db5305a2ba476d6b5a0e01cab17e',1,'Npgsql::NpgsqlConnection']]],
  ['connectiontimeout',['ConnectionTimeout',['../class_npgsql_1_1_npgsql_connection.html#a21b4fd6bd8f6ffe7aecb7b646b129829',1,'Npgsql::NpgsqlConnection']]],
  ['constraintname',['ConstraintName',['../class_npgsql_1_1_npgsql_error.html#a8512cc0ad9eaf14932b4523ff213188f',1,'Npgsql.NpgsqlError.ConstraintName()'],['../class_npgsql_1_1_npgsql_exception.html#a89302f105a2acc180977b4f9fb539ee7',1,'Npgsql.NpgsqlException.ConstraintName()']]],
  ['copybuffersize',['CopyBufferSize',['../class_npgsql_1_1_npgsql_copy_in.html#a2ac7a0c748a4d4c7627967ca8d769379',1,'Npgsql::NpgsqlCopyIn']]],
  ['copystream',['CopyStream',['../class_npgsql_1_1_npgsql_copy_in.html#a8fe5f06119e6630e2f468563c110a9d5',1,'Npgsql.NpgsqlCopyIn.CopyStream()'],['../class_npgsql_1_1_npgsql_copy_out.html#a41189cfed38249c3127d50258e9285a3',1,'Npgsql.NpgsqlCopyOut.CopyStream()']]],
  ['count',['Count',['../class_npgsql_1_1_npgsql_parameter_collection.html#a28f6c5553062f6f43f3827d88398e000',1,'Npgsql::NpgsqlParameterCollection']]]
];
