var searchData=
[
  ['pid',['PID',['../class_npgsql_1_1_npgsql_notification_event_args.html#acc2cfec137c155c63f71b76590dcba66',1,'Npgsql::NpgsqlNotificationEventArgs']]]
];
