var searchData=
[
  ['condition',['Condition',['../class_npgsql_1_1_npgsql_notification_event_args.html#a08b1adce25706e5ec03b10433b3348ec',1,'Npgsql::NpgsqlNotificationEventArgs']]]
];
