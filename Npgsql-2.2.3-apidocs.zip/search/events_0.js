var searchData=
[
  ['certificateselectioncallback',['CertificateSelectionCallback',['../class_npgsql_1_1_npgsql_connection.html#a1eb6e7cb00a74d7fad183509259cb815',1,'Npgsql::NpgsqlConnection']]],
  ['certificatevalidationcallback',['CertificateValidationCallback',['../class_npgsql_1_1_npgsql_connection.html#aaf99020b77aa454b4bf9618cd9a7e0a4',1,'Npgsql::NpgsqlConnection']]]
];
