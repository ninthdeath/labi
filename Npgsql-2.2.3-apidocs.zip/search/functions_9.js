var searchData=
[
  ['makeroomforbytes',['MakeRoomForBytes',['../class_npgsql_1_1_npgsql_copy_serializer.html#a8b5e17901c19ad8901fc520bc922af64',1,'Npgsql::NpgsqlCopySerializer']]]
];
