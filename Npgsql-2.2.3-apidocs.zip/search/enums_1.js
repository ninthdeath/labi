var searchData=
[
  ['protocolversion',['ProtocolVersion',['../namespace_npgsql.html#a546dace9064e3555c3133f7046d8fd2e',1,'Npgsql']]]
];
