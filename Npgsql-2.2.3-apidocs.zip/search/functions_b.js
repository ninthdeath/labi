var searchData=
[
  ['onrowupdated',['OnRowUpdated',['../class_npgsql_1_1_npgsql_data_adapter.html#aff594a252ff86c893a729685b44ad506',1,'Npgsql::NpgsqlDataAdapter']]],
  ['onrowupdating',['OnRowUpdating',['../class_npgsql_1_1_npgsql_data_adapter.html#aa4596dca4a1b2c2444c6e9c91ffd467a',1,'Npgsql::NpgsqlDataAdapter']]],
  ['open',['Open',['../class_npgsql_1_1_npgsql_connection.html#a17b7e9203625431c0d6d5c5396d5183b',1,'Npgsql::NpgsqlConnection']]]
];
