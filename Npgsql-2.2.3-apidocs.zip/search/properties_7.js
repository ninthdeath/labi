var searchData=
[
  ['insertcommand',['InsertCommand',['../class_npgsql_1_1_npgsql_data_adapter.html#a7c0248e5b1917009dfa7f14d02bc83f2',1,'Npgsql::NpgsqlDataAdapter']]],
  ['internalposition',['InternalPosition',['../class_npgsql_1_1_npgsql_error.html#aabdba9ae985d339a61132cee78281713',1,'Npgsql::NpgsqlError']]],
  ['internalquery',['InternalQuery',['../class_npgsql_1_1_npgsql_error.html#ab704b225a6a5efdc1f4b0fa114499eeb',1,'Npgsql::NpgsqlError']]],
  ['isactive',['IsActive',['../class_npgsql_1_1_npgsql_copy_in.html#aa046cd8117869f2dc759505953ab33e2',1,'Npgsql.NpgsqlCopyIn.IsActive()'],['../class_npgsql_1_1_npgsql_copy_out.html#a8c0333a2c168d2d0ebfc42fa273d360d',1,'Npgsql.NpgsqlCopyOut.IsActive()'],['../class_npgsql_1_1_npgsql_copy_serializer.html#a89460056aee6e79cb0dd888d7b39d779',1,'Npgsql.NpgsqlCopySerializer.IsActive()']]],
  ['isbinary',['IsBinary',['../class_npgsql_1_1_npgsql_copy_format.html#a69a6af0f171bac7d439f533c2a399996',1,'Npgsql.NpgsqlCopyFormat.IsBinary()'],['../class_npgsql_1_1_npgsql_copy_in.html#a37c9f2ea6f171e4b35b47dfd31c22372',1,'Npgsql.NpgsqlCopyIn.IsBinary()'],['../class_npgsql_1_1_npgsql_copy_out.html#a7cb7f26c284ccba074e785afa79e1723',1,'Npgsql.NpgsqlCopyOut.IsBinary()']]],
  ['isclosed',['IsClosed',['../class_npgsql_1_1_npgsql_data_reader.html#a3273e82c75ca9512a2ce098014621374',1,'Npgsql::NpgsqlDataReader']]],
  ['isfixedsize',['IsFixedSize',['../class_npgsql_1_1_npgsql_parameter_collection.html#a7e5897ee1d01875bb825519ac7118f7f',1,'Npgsql::NpgsqlParameterCollection']]],
  ['isnullable',['IsNullable',['../class_npgsql_1_1_npgsql_parameter.html#a392f588de4b006c1778a0ac51a9456f9',1,'Npgsql::NpgsqlParameter']]],
  ['isolationlevel',['IsolationLevel',['../class_npgsql_1_1_npgsql_transaction.html#a9a73087b0c8ee2696b61a46657408ed6',1,'Npgsql::NpgsqlTransaction']]],
  ['isprepared',['IsPrepared',['../class_npgsql_1_1_npgsql_command.html#ae627f51e2fadd1e60de83e9e918233e4',1,'Npgsql::NpgsqlCommand']]],
  ['isreadonly',['IsReadOnly',['../class_npgsql_1_1_npgsql_parameter_collection.html#aab6dee7bb9bb0ff9929046252fb7985a',1,'Npgsql::NpgsqlParameterCollection']]],
  ['issynchronized',['IsSynchronized',['../class_npgsql_1_1_npgsql_parameter_collection.html#acb1c3ceef6ff616600fb942e6789e8c7',1,'Npgsql::NpgsqlParameterCollection']]]
];
