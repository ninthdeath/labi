var searchData=
[
  ['lastinsertedoid',['LastInsertedOID',['../class_npgsql_1_1_npgsql_command.html#a518c322dd456fba1923b8881a9571df6',1,'Npgsql::NpgsqlCommand']]],
  ['line',['Line',['../class_npgsql_1_1_npgsql_error.html#acc779f1432e415d78f7ceddc9b1e8c49',1,'Npgsql.NpgsqlError.Line()'],['../class_npgsql_1_1_npgsql_exception.html#a32bec996da73bb2eabbab935390de5c1',1,'Npgsql.NpgsqlException.Line()'],['../class_npgsql_1_1_npgsql_error.html#a4839b846e4a8c8f3e44a461e393991e7a4803e6b9e63dabf04de980788d6a13c4',1,'Npgsql.NpgsqlError.Line()']]],
  ['loglevel',['LogLevel',['../namespace_npgsql.html#a012be6ba61a69f4a6b298eed8c6fd371',1,'Npgsql']]],
  ['logname',['LogName',['../class_npgsql_1_1_npgsql_event_log.html#affc72d8b788ecfc25ac2c7810c80fb7f',1,'Npgsql::NpgsqlEventLog']]]
];
