var searchData=
[
  ['routine',['Routine',['../class_npgsql_1_1_npgsql_error.html#a4839b846e4a8c8f3e44a461e393991e7a0eded4c20517f36e44e66cf33fd5951e',1,'Npgsql::NpgsqlError']]]
];
