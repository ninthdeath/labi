var searchData=
[
  ['validateremotecertificatecallback',['ValidateRemoteCertificateCallback',['../class_npgsql_1_1_npgsql_connection.html#aa38144ca7e292f97fc63e871649983e4',1,'Npgsql::NpgsqlConnection']]]
];
