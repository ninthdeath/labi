var searchData=
[
  ['npgsql',['Npgsql',['../namespace_npgsql.html',1,'']]],
  ['sqlgenerators',['SqlGenerators',['../namespace_npgsql_1_1_sql_generators.html',1,'Npgsql']]]
];
