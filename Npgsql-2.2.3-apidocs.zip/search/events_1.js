var searchData=
[
  ['notice',['Notice',['../class_npgsql_1_1_npgsql_connection.html#a39c9acafb85c67ccbfbe01f2e469c34b',1,'Npgsql::NpgsqlConnection']]],
  ['notification',['Notification',['../class_npgsql_1_1_npgsql_connection.html#ab3e626b0bbe5e239bff36059a357521a',1,'Npgsql::NpgsqlConnection']]]
];
