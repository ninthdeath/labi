var searchData=
[
  ['major',['Major',['../class_npgsql_1_1_server_version.html#a85f3ce6612c012d1d5af926a6e0641d9',1,'Npgsql::ServerVersion']]],
  ['maxpoolsize',['MaxPoolSize',['../class_npgsql_1_1_npgsql_connection_string_builder.html#ad842ac35ed92e1bab5fde21abfbd479b',1,'Npgsql::NpgsqlConnectionStringBuilder']]],
  ['message',['Message',['../class_npgsql_1_1_npgsql_error.html#a3fdf2c2e58988ffb1641524b6934a499',1,'Npgsql::NpgsqlError']]],
  ['minor',['Minor',['../class_npgsql_1_1_server_version.html#a556510fa92d0017aba21d42d2458ddf6',1,'Npgsql::ServerVersion']]],
  ['minpoolsize',['MinPoolSize',['../class_npgsql_1_1_npgsql_connection_string_builder.html#a9fa22a2efdfce176645727133245bcd2',1,'Npgsql::NpgsqlConnectionStringBuilder']]]
];
