﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
namespace ConsoleApplication60
{
    class Program
    {

        public static void Main(string[] args)

        {
            NpgsqlConnection conn = new NpgsqlConnection("Server=127.0.0.1;Port=5432;User Id=postgres;Password=76377763w;Database=supercars;");
            NpgsqlConnection con = new NpgsqlConnection("Server=127.0.0.1;Port=5432;User Id=postgres;Password=76377763w;Database=db1;");
            NpgsqlConnection connection = new NpgsqlConnection("Server=127.0.0.1;Port=5432;User Id=postgres;Password=76377763w;Database=db2;");
            conn.Open();

         //   bool a = true;
       // if ()
           // if (  a = Convert.ToBoolean Console.ReadKey(1))
           ////// private bool nonNumberEntered = false;
        //  NpgsqlDataAdapter dbDataAdapter = new NpgsqlDataAdapter();
      ///  nonNumberEntered = false;
        ///    if ()
                
            
            NpgsqlCommand update = new NpgsqlCommand("insert into super values(7, 'zr-1', 800, 360)", conn);
              NpgsqlCommand command = new NpgsqlCommand("select *  from super where id % 2 = 0", conn);
             NpgsqlCommand com = new NpgsqlCommand("update  super set speed = 100500 where id = 1", conn);
            NpgsqlCommand del = new NpgsqlCommand("delete from super where id = 7", conn);
           

            int aaa;
            try
            {
                
                // aaa = com.ExecuteNonQuery();
                //  aaa = update.ExecuteNonQuery();
                //  aaa = del.ExecuteNonQuery();
              //  aaa = del.ExecuteNonQuery();
               NpgsqlDataReader dr = command.ExecuteReader();
                while (dr.Read())
                   
                {
                    for (int i = 0; i < dr.FieldCount; i++)
                    {
                        Console.Write("{0} \t", dr[i]);
                    }
                    Console.WriteLine();
                }
             
             
              

            }
            
            catch (NpgsqlException ex)
            {
                Console.Write(ex.ToString());
            }
            finally
            {
                conn.Close();
            }

            Console.Write(" \n Press any key to continue . . . ");
            Console.ReadKey(true);
        }
    }
}