var searchData=
[
  ['internalposition',['InternalPosition',['../class_npgsql_1_1_npgsql_error.html#a4839b846e4a8c8f3e44a461e393991e7a4e241c39aba2d6fea647d761ee7c90c6',1,'Npgsql::NpgsqlError']]],
  ['internalquery',['InternalQuery',['../class_npgsql_1_1_npgsql_error.html#a4839b846e4a8c8f3e44a461e393991e7a8dab27d8cc4710fc99edb39498cd3e23',1,'Npgsql::NpgsqlError']]]
];
