var searchData=
[
  ['indexof',['IndexOf',['../class_npgsql_1_1_npgsql_parameter_collection.html#ab5659ddc842759981db8e6a07443de70',1,'Npgsql.NpgsqlParameterCollection.IndexOf(string parameterName)'],['../class_npgsql_1_1_npgsql_parameter_collection.html#ab9c0e61a243be0d678676d450bbf828f',1,'Npgsql.NpgsqlParameterCollection.IndexOf(object value)'],['../class_npgsql_1_1_npgsql_parameter_collection.html#ad647efc64711ddbf33295ce36a30fe3c',1,'Npgsql.NpgsqlParameterCollection.IndexOf(NpgsqlParameter item)']]],
  ['insert',['Insert',['../class_npgsql_1_1_npgsql_parameter_collection.html#ae73c530d66d0282e2a03f5317c43a832',1,'Npgsql.NpgsqlParameterCollection.Insert(int index, object oValue)'],['../class_npgsql_1_1_npgsql_parameter_collection.html#abc3bf7d1aa73ccd59e538d6e6e9614bb',1,'Npgsql.NpgsqlParameterCollection.Insert(int index, NpgsqlParameter item)']]]
];
