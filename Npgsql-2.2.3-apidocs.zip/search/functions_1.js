var searchData=
[
  ['begindbtransaction',['BeginDbTransaction',['../class_npgsql_1_1_npgsql_connection.html#a88e0ca71924be81c49d371c8c23a8e43',1,'Npgsql::NpgsqlConnection']]],
  ['begintransaction',['BeginTransaction',['../class_npgsql_1_1_npgsql_connection.html#aa6fe2996b2dbecbc479598b0ead2ad05',1,'Npgsql.NpgsqlConnection.BeginTransaction()'],['../class_npgsql_1_1_npgsql_connection.html#adaa2ded0ecd8100efa14c103061257c2',1,'Npgsql.NpgsqlConnection.BeginTransaction(IsolationLevel level)']]]
];
