var searchData=
[
  ['quoteidentifier',['QuoteIdentifier',['../class_npgsql_1_1_npgsql_command_builder.html#a04ebafcc1c1f77c7d2285c5f3c81fed6',1,'Npgsql::NpgsqlCommandBuilder']]]
];
