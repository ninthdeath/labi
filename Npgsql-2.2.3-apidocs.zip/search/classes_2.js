var searchData=
[
  ['fielddata',['FieldData',['../class_npgsql_1_1_npgsql_row_description_1_1_field_data.html',1,'Npgsql::NpgsqlRowDescription']]]
];
