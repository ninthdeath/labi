var searchData=
[
  ['hint',['Hint',['../class_npgsql_1_1_npgsql_error.html#a92fa74288670df57c50784b4ead9f5e6',1,'Npgsql.NpgsqlError.Hint()'],['../class_npgsql_1_1_npgsql_exception.html#a279996e7572c4031cb4ef65a66adfe8e',1,'Npgsql.NpgsqlException.Hint()']]],
  ['host',['Host',['../class_npgsql_1_1_npgsql_connection.html#ad6638b9c1f616623ec20a4c4aa05b8dc',1,'Npgsql.NpgsqlConnection.Host()'],['../class_npgsql_1_1_npgsql_connection_string_builder.html#a6cac1e7072c7d01b41cd086862ee56b7',1,'Npgsql.NpgsqlConnectionStringBuilder.Host()']]]
];
