var searchData=
[
  ['loglevel',['LogLevel',['../namespace_npgsql.html#a012be6ba61a69f4a6b298eed8c6fd371',1,'Npgsql']]]
];
