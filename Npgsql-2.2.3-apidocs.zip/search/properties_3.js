var searchData=
[
  ['datasource',['DataSource',['../class_npgsql_1_1_npgsql_connection.html#a868bf18251268ad33a07ebcd2f4ef78b',1,'Npgsql::NpgsqlConnection']]],
  ['datatypename',['DataTypeName',['../class_npgsql_1_1_npgsql_error.html#a58246908b7612a12d2040a9e7a7ddd68',1,'Npgsql.NpgsqlError.DataTypeName()'],['../class_npgsql_1_1_npgsql_exception.html#a16c78a89b0c8965825052d7294f0dca7',1,'Npgsql.NpgsqlException.DataTypeName()']]],
  ['dbconnection',['DbConnection',['../class_npgsql_1_1_npgsql_command.html#ab73ddc764c117aaaaee17198f294acdc',1,'Npgsql.NpgsqlCommand.DbConnection()'],['../class_npgsql_1_1_npgsql_transaction.html#a9ecf357c07704a54af9d7a32e36ccbfc',1,'Npgsql.NpgsqlTransaction.DbConnection()']]],
  ['dbparametercollection',['DbParameterCollection',['../class_npgsql_1_1_npgsql_command.html#ab78f81e2aa303005ff983a085426801f',1,'Npgsql::NpgsqlCommand']]],
  ['dbtransaction',['DbTransaction',['../class_npgsql_1_1_npgsql_command.html#ab78d6f65261e4c171687c4ebb9f07ad1',1,'Npgsql::NpgsqlCommand']]],
  ['dbtype',['DbType',['../class_npgsql_1_1_npgsql_parameter.html#a26f28a781ac04ee180e466078297d1c8',1,'Npgsql::NpgsqlParameter']]],
  ['deletecommand',['DeleteCommand',['../class_npgsql_1_1_npgsql_data_adapter.html#ab6b3bce6dffe89af977179f0d7589206',1,'Npgsql::NpgsqlDataAdapter']]],
  ['delimiter',['Delimiter',['../class_npgsql_1_1_npgsql_copy_serializer.html#a2006cafa3d3a34db332f0e18eaacc779',1,'Npgsql::NpgsqlCopySerializer']]],
  ['depth',['Depth',['../class_npgsql_1_1_npgsql_data_reader.html#a8cb9da3feef57e1073aab98ab8b469e3',1,'Npgsql::NpgsqlDataReader']]],
  ['designtimevisible',['DesignTimeVisible',['../class_npgsql_1_1_npgsql_command.html#ad30642f6434e2b2e8bc4778db4e947e5',1,'Npgsql::NpgsqlCommand']]],
  ['detail',['Detail',['../class_npgsql_1_1_npgsql_error.html#ac07f139bbdd6b568f196248dfe528bde',1,'Npgsql.NpgsqlError.Detail()'],['../class_npgsql_1_1_npgsql_exception.html#a2c4cb7f9036d787062945db89b2f0239',1,'Npgsql.NpgsqlException.Detail()']]],
  ['direction',['Direction',['../class_npgsql_1_1_npgsql_parameter.html#a3c948ce5804ea78cc99d95ba24d50fe1',1,'Npgsql::NpgsqlParameter']]]
];
