var searchData=
[
  ['validateremotecertificatecallback',['ValidateRemoteCertificateCallback',['../class_npgsql_1_1_npgsql_connection.html#aa38144ca7e292f97fc63e871649983e4',1,'Npgsql.NpgsqlConnection.ValidateRemoteCertificateCallback()'],['../namespace_npgsql.html#acbfbb5f4dcaf2d261f2fe16b71c5d8b2',1,'Npgsql.ValidateRemoteCertificateCallback()']]],
  ['value',['Value',['../class_npgsql_1_1_npgsql_parameter.html#a98f0a6fcb96a20712e6376b065c63da7',1,'Npgsql::NpgsqlParameter']]]
];
