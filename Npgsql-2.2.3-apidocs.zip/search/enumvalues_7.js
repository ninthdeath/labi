var searchData=
[
  ['none',['None',['../namespace_npgsql.html#a012be6ba61a69f4a6b298eed8c6fd371a6adf97f83acf6453d4a6a4b1070f3754',1,'Npgsql']]],
  ['normal',['Normal',['../namespace_npgsql.html#a012be6ba61a69f4a6b298eed8c6fd371a960b44c579bc2f6818d2daaf9e4c16f0',1,'Npgsql']]]
];
