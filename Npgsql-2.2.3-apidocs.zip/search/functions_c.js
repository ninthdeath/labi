var searchData=
[
  ['prefixfield',['PrefixField',['../class_npgsql_1_1_npgsql_copy_serializer.html#ab622cb4841f3985eff0d919d020a55f4',1,'Npgsql::NpgsqlCopySerializer']]],
  ['prepare',['Prepare',['../class_npgsql_1_1_npgsql_command.html#a39eb36fd929bf5931a58d1d91ad26302',1,'Npgsql::NpgsqlCommand']]],
  ['provideclientcertificatescallback',['ProvideClientCertificatesCallback',['../namespace_npgsql.html#ab2e0593fad08b9c5ed833a163b71282b',1,'Npgsql']]]
];
