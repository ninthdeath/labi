var searchData=
[
  ['tablename',['TableName',['../class_npgsql_1_1_npgsql_error.html#a4839b846e4a8c8f3e44a461e393991e7ae6ef4acd2d963975fe27f87ba15441c0',1,'Npgsql::NpgsqlError']]]
];
