var searchData=
[
  ['code',['Code',['../class_npgsql_1_1_npgsql_error.html#a4839b846e4a8c8f3e44a461e393991e7aca0dbad92a874b2f69b549293387925e',1,'Npgsql::NpgsqlError']]],
  ['columnname',['ColumnName',['../class_npgsql_1_1_npgsql_error.html#a4839b846e4a8c8f3e44a461e393991e7a7118cae6590a9888bc3ef7439041371c',1,'Npgsql::NpgsqlError']]],
  ['constraintname',['ConstraintName',['../class_npgsql_1_1_npgsql_error.html#a4839b846e4a8c8f3e44a461e393991e7a2c33fecb23358441ab084aa5a5307b18',1,'Npgsql::NpgsqlError']]]
];
