var searchData=
[
  ['read',['Read',['../class_npgsql_1_1_npgsql_copy_out.html#acc6a846bbdfeeae998fd25b82fdd6e36',1,'Npgsql::NpgsqlCopyOut']]],
  ['readerclosed',['ReaderClosed',['../class_npgsql_1_1_npgsql_data_reader.html#a5385675d4960ddd2267d2cdea66f86b8',1,'Npgsql::NpgsqlDataReader']]],
  ['remove',['Remove',['../class_npgsql_1_1_npgsql_parameter_collection.html#a22c4b6576a840c28578081d30842338d',1,'Npgsql.NpgsqlParameterCollection.Remove(string parameterName)'],['../class_npgsql_1_1_npgsql_parameter_collection.html#a26ff6559f35d00666012c699a01c4784',1,'Npgsql.NpgsqlParameterCollection.Remove(object oValue)'],['../class_npgsql_1_1_npgsql_parameter_collection.html#a35d9b25fb09a963af35fa3c6346483d3',1,'Npgsql.NpgsqlParameterCollection.Remove(NpgsqlParameter item)']]],
  ['removeat',['RemoveAt',['../class_npgsql_1_1_npgsql_parameter_collection.html#a5e377641a42679863188a639bdeead35',1,'Npgsql.NpgsqlParameterCollection.RemoveAt(string parameterName)'],['../class_npgsql_1_1_npgsql_parameter_collection.html#a1b1cfc05a179ecad0a70f843814842c8',1,'Npgsql.NpgsqlParameterCollection.RemoveAt(int index)']]],
  ['resetdbtype',['ResetDbType',['../class_npgsql_1_1_npgsql_parameter.html#ab657a5fcc12b2a1ca865527c645fcb65',1,'Npgsql::NpgsqlParameter']]],
  ['rollback',['Rollback',['../class_npgsql_1_1_npgsql_transaction.html#a0eb057ac5e4b9b48c2ccbd2ce951c2a2',1,'Npgsql.NpgsqlTransaction.Rollback()'],['../class_npgsql_1_1_npgsql_transaction.html#a6b1af30f8241e603d7ecd6a51291bf97',1,'Npgsql.NpgsqlTransaction.Rollback(String savePointName)']]],
  ['routine',['Routine',['../class_npgsql_1_1_npgsql_error.html#afc5d161b47c92ff3a914d58b4fbeb5da',1,'Npgsql.NpgsqlError.Routine()'],['../class_npgsql_1_1_npgsql_exception.html#a3d6517dd4aa4bca312b8e24b16faa93f',1,'Npgsql.NpgsqlException.Routine()'],['../class_npgsql_1_1_npgsql_error.html#a4839b846e4a8c8f3e44a461e393991e7a0eded4c20517f36e44e66cf33fd5951e',1,'Npgsql.NpgsqlError.Routine()']]],
  ['rowupdated',['RowUpdated',['../class_npgsql_1_1_npgsql_data_adapter.html#a7afcb185428ed42c66970c411857901a',1,'Npgsql::NpgsqlDataAdapter']]],
  ['rowupdating',['RowUpdating',['../class_npgsql_1_1_npgsql_data_adapter.html#a7ca228566b6152ef3740fca283a2c9fc',1,'Npgsql::NpgsqlDataAdapter']]]
];
