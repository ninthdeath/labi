var searchData=
[
  ['unquoteidentifier',['UnquoteIdentifier',['../class_npgsql_1_1_npgsql_command_builder.html#a3251aa934037be1b7feec151fa72e2c3',1,'Npgsql::NpgsqlCommandBuilder']]],
  ['updatecommand',['UpdateCommand',['../class_npgsql_1_1_npgsql_data_adapter.html#af6eecb00b357cb2686adc19727611996',1,'Npgsql::NpgsqlDataAdapter']]],
  ['updatedrowsource',['UpdatedRowSource',['../class_npgsql_1_1_npgsql_command.html#ab8823c98fb7f1ad1c494330e6754e74a',1,'Npgsql::NpgsqlCommand']]],
  ['usecast',['UseCast',['../class_npgsql_1_1_npgsql_parameter.html#abf9041d0b4b05db797b2138913c2023a',1,'Npgsql::NpgsqlParameter']]],
  ['useconformantstrings',['UseConformantStrings',['../class_npgsql_1_1_npgsql_connection.html#a48232dcc41da153873b91d771ce9c3a5',1,'Npgsql::NpgsqlConnection']]],
  ['useextendedtypes',['UseExtendedTypes',['../class_npgsql_1_1_npgsql_connection.html#a45871b2a0ac01ccc3634db1df011659c',1,'Npgsql::NpgsqlConnection']]],
  ['username',['UserName',['../class_npgsql_1_1_npgsql_connection_string_builder.html#a54b05c5579534d176766e554b76b6b03',1,'Npgsql::NpgsqlConnectionStringBuilder']]]
];
