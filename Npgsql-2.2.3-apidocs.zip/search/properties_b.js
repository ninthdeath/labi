var searchData=
[
  ['parametername',['ParameterName',['../class_npgsql_1_1_npgsql_parameter.html#a659a9519539dbb07304100c48f8bbad9',1,'Npgsql::NpgsqlParameter']]],
  ['parameters',['Parameters',['../class_npgsql_1_1_npgsql_command.html#a8034fbfcc069119bd910cbd04bd2b1af',1,'Npgsql::NpgsqlCommand']]],
  ['password',['Password',['../class_npgsql_1_1_npgsql_connection_string_builder.html#a73ce219367a4720794fe29bf2feeb916',1,'Npgsql::NpgsqlConnectionStringBuilder']]],
  ['passwordasbytearray',['PasswordAsByteArray',['../class_npgsql_1_1_npgsql_connection_string_builder.html#a50f53f9fef24492f41632ad05a8982dc',1,'Npgsql::NpgsqlConnectionStringBuilder']]],
  ['patch',['Patch',['../class_npgsql_1_1_server_version.html#a78d2326357e3cb078264b2809f66c2d3',1,'Npgsql::ServerVersion']]],
  ['pooling',['Pooling',['../class_npgsql_1_1_npgsql_connection_string_builder.html#af2a32c2202ceee11e857e3c8a19578f4',1,'Npgsql::NpgsqlConnectionStringBuilder']]],
  ['port',['Port',['../class_npgsql_1_1_npgsql_connection.html#a22abb02fad05f52b665564ed216198e2',1,'Npgsql.NpgsqlConnection.Port()'],['../class_npgsql_1_1_npgsql_connection_string_builder.html#a9dde6984cdd7a3991f42c309d9777e0d',1,'Npgsql.NpgsqlConnectionStringBuilder.Port()']]],
  ['position',['Position',['../class_npgsql_1_1_npgsql_error.html#ad9430985b25a63ada81a7f61456818e4',1,'Npgsql.NpgsqlError.Position()'],['../class_npgsql_1_1_npgsql_exception.html#ab68d63d25e6fcdbe87132c7945e233f7',1,'Npgsql.NpgsqlException.Position()']]],
  ['postgresqlversion',['PostgreSqlVersion',['../class_npgsql_1_1_npgsql_connection.html#a0dec277bcfb0f88366f4813e23a1b293',1,'Npgsql::NpgsqlConnection']]],
  ['precision',['Precision',['../class_npgsql_1_1_npgsql_parameter.html#a0f7505ce807c53c5fc3b1bdfe9ff0f5e',1,'Npgsql::NpgsqlParameter']]],
  ['preloadreader',['PreloadReader',['../class_npgsql_1_1_npgsql_connection.html#a53000ad75f92391d61afd814ee371256',1,'Npgsql.NpgsqlConnection.PreloadReader()'],['../class_npgsql_1_1_npgsql_connection_string_builder.html#a4642dc937acb088f13a72cf2acf04185',1,'Npgsql.NpgsqlConnectionStringBuilder.PreloadReader()']]],
  ['processid',['ProcessID',['../class_npgsql_1_1_npgsql_connection.html#a0ec67cb4ed00fac0c9e4858eb0402bf9',1,'Npgsql::NpgsqlConnection']]],
  ['protocol',['Protocol',['../class_npgsql_1_1_npgsql_connection_string_builder.html#a4e9888c193bd4b526aa89e0b75360c81',1,'Npgsql::NpgsqlConnectionStringBuilder']]]
];
