var searchData=
[
  ['default_5fbuffer_5fsize',['DEFAULT_BUFFER_SIZE',['../class_npgsql_1_1_npgsql_copy_serializer.html#ab8f6f870a47c48c04cf9d2fd690c9a59',1,'Npgsql::NpgsqlCopySerializer']]],
  ['default_5fdelimiter',['DEFAULT_DELIMITER',['../class_npgsql_1_1_npgsql_copy_serializer.html#ac3c90dce8ae3268ebc926aeb17ea8806',1,'Npgsql::NpgsqlCopySerializer']]],
  ['default_5fescape',['DEFAULT_ESCAPE',['../class_npgsql_1_1_npgsql_copy_serializer.html#a8d83f981352c9940eb55f3d552b7b7a0',1,'Npgsql::NpgsqlCopySerializer']]],
  ['default_5fnull',['DEFAULT_NULL',['../class_npgsql_1_1_npgsql_copy_serializer.html#a3e1d52ec752100da1f1a2daf7ade0b09',1,'Npgsql::NpgsqlCopySerializer']]],
  ['default_5fquote',['DEFAULT_QUOTE',['../class_npgsql_1_1_npgsql_copy_serializer.html#a49104442c889de449fc358d6fde871c2',1,'Npgsql::NpgsqlCopySerializer']]],
  ['default_5fseparator',['DEFAULT_SEPARATOR',['../class_npgsql_1_1_npgsql_copy_serializer.html#ae47358499bf4c8cbbb5c1c4a4b795d7e',1,'Npgsql::NpgsqlCopySerializer']]]
];
