var searchData=
[
  ['validateremotecertificatecallback',['ValidateRemoteCertificateCallback',['../namespace_npgsql.html#acbfbb5f4dcaf2d261f2fe16b71c5d8b2',1,'Npgsql']]]
];
