var searchData=
[
  ['orderbyexpression',['OrderByExpression',['../class_npgsql_1_1_sql_generators_1_1_order_by_expression.html',1,'Npgsql::SqlGenerators']]]
];
