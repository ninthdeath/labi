var searchData=
[
  ['backendprotocolversion',['BackendProtocolVersion',['../class_npgsql_1_1_npgsql_connection.html#a192b3157c6985bbc09cefdbe26cf14eb',1,'Npgsql::NpgsqlConnection']]],
  ['basemessage',['BaseMessage',['../class_npgsql_1_1_npgsql_exception.html#ac6d0af199664a9444075c958c89c2c80',1,'Npgsql::NpgsqlException']]],
  ['begindbtransaction',['BeginDbTransaction',['../class_npgsql_1_1_npgsql_connection.html#a88e0ca71924be81c49d371c8c23a8e43',1,'Npgsql::NpgsqlConnection']]],
  ['begintransaction',['BeginTransaction',['../class_npgsql_1_1_npgsql_connection.html#aa6fe2996b2dbecbc479598b0ead2ad05',1,'Npgsql.NpgsqlConnection.BeginTransaction()'],['../class_npgsql_1_1_npgsql_connection.html#adaa2ded0ecd8100efa14c103061257c2',1,'Npgsql.NpgsqlConnection.BeginTransaction(IsolationLevel level)']]],
  ['buffersize',['BufferSize',['../class_npgsql_1_1_npgsql_copy_serializer.html#a6e1f68291558a5a642f7fb0863464368',1,'Npgsql::NpgsqlCopySerializer']]],
  ['bytestreamer',['ByteStreamer',['../class_npgsql_1_1_row_reader_1_1_byte_streamer.html',1,'Npgsql::RowReader']]]
];
