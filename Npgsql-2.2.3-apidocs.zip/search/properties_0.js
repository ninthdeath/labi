var searchData=
[
  ['alwaysprepare',['AlwaysPrepare',['../class_npgsql_1_1_npgsql_connection_string_builder.html#a2530cee2c6aaab8313a45e6d09b27c00',1,'Npgsql::NpgsqlConnectionStringBuilder']]],
  ['applicationname',['ApplicationName',['../class_npgsql_1_1_npgsql_connection_string_builder.html#acd34c95dbb908151170546ebff17bd91',1,'Npgsql::NpgsqlConnectionStringBuilder']]]
];
