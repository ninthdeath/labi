var searchData=
[
  ['notice',['Notice',['../class_npgsql_1_1_npgsql_notice_event_args.html#aa524dc7e99d341cc11abaa3e18c72460',1,'Npgsql::NpgsqlNoticeEventArgs']]]
];
