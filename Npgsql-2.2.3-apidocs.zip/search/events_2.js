var searchData=
[
  ['privatekeyselectioncallback',['PrivateKeySelectionCallback',['../class_npgsql_1_1_npgsql_connection.html#ada89ef7e49e5795fec4d1011a6f407d7',1,'Npgsql::NpgsqlConnection']]],
  ['provideclientcertificatescallback',['ProvideClientCertificatesCallback',['../class_npgsql_1_1_npgsql_connection.html#a5420daec2121bed8e82cb00dd8b3fc03',1,'Npgsql::NpgsqlConnection']]]
];
