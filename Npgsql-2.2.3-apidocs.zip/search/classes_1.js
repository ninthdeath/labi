var searchData=
[
  ['charstreamer',['CharStreamer',['../class_npgsql_1_1_row_reader_1_1_char_streamer.html',1,'Npgsql::RowReader']]]
];
