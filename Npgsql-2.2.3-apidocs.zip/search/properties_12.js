var searchData=
[
  ['where',['Where',['../class_npgsql_1_1_npgsql_error.html#a65fe7b4eb6a12daa4bad7098e2d0afca',1,'Npgsql.NpgsqlError.Where()'],['../class_npgsql_1_1_npgsql_exception.html#a60c117190f2b9102e0d1671546054d6a',1,'Npgsql.NpgsqlException.Where()']]]
];
