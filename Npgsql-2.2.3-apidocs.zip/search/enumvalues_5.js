var searchData=
[
  ['line',['Line',['../class_npgsql_1_1_npgsql_error.html#a4839b846e4a8c8f3e44a461e393991e7a4803e6b9e63dabf04de980788d6a13c4',1,'Npgsql::NpgsqlError']]]
];
