var searchData=
[
  ['unquoteidentifier',['UnquoteIdentifier',['../class_npgsql_1_1_npgsql_command_builder.html#a3251aa934037be1b7feec151fa72e2c3',1,'Npgsql::NpgsqlCommandBuilder']]]
];
