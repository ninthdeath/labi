var searchData=
[
  ['additionalinformation',['AdditionalInformation',['../class_npgsql_1_1_npgsql_notification_event_args.html#af1f7c036900382edacb88d0a842cbdce',1,'Npgsql::NpgsqlNotificationEventArgs']]]
];
