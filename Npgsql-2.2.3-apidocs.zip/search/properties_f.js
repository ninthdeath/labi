var searchData=
[
  ['tablename',['TableName',['../class_npgsql_1_1_npgsql_error.html#ae1a0b9363e663c2ee0c887ee93341bf6',1,'Npgsql.NpgsqlError.TableName()'],['../class_npgsql_1_1_npgsql_exception.html#af6927ca1a0e82383328b7c2c905ee91b',1,'Npgsql.NpgsqlException.TableName()']]],
  ['this_5bint_20index_5d',['this[int index]',['../class_npgsql_1_1_npgsql_parameter_collection.html#a0971d868cca49804be184cec61dfd300',1,'Npgsql::NpgsqlParameterCollection']]],
  ['this_5bint32_20i_5d',['this[Int32 i]',['../class_npgsql_1_1_npgsql_data_reader.html#ae375fa1e8e72b45621576841e03ebdcf',1,'Npgsql::NpgsqlDataReader']]],
  ['this_5bint32_20index_5d',['this[Int32 Index]',['../class_npgsql_1_1_npgsql_exception.html#ad877a1173cdb2e22c1cf9b254926782f',1,'Npgsql::NpgsqlException']]],
  ['this_5bstring_20keyword_5d',['this[string keyword]',['../class_npgsql_1_1_npgsql_connection_string_builder.html#a9c83407ceacbd9a2fae379b53cd8eabc',1,'Npgsql::NpgsqlConnectionStringBuilder']]],
  ['this_5bstring_20name_5d',['this[String name]',['../class_npgsql_1_1_npgsql_data_reader.html#a50c4802196f75a89e2aac6d3eaaa9842',1,'Npgsql::NpgsqlDataReader']]],
  ['this_5bstring_20parametername_5d',['this[string parameterName]',['../class_npgsql_1_1_npgsql_parameter_collection.html#afd68132d2771a03859851e949dfe08f7',1,'Npgsql::NpgsqlParameterCollection']]],
  ['timeout',['Timeout',['../class_npgsql_1_1_npgsql_connection_string_builder.html#af360d80ac8371e12e22207d524151d01',1,'Npgsql::NpgsqlConnectionStringBuilder']]],
  ['tostream',['ToStream',['../class_npgsql_1_1_npgsql_copy_serializer.html#a11c58173363d7427a2ee813f72876c95',1,'Npgsql::NpgsqlCopySerializer']]],
  ['transaction',['Transaction',['../class_npgsql_1_1_npgsql_command.html#a8ecdc6dbae99964bfe2f1e2c502c084a',1,'Npgsql::NpgsqlCommand']]]
];
