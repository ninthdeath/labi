var searchData=
[
  ['hint',['Hint',['../class_npgsql_1_1_npgsql_error.html#a4839b846e4a8c8f3e44a461e393991e7ad11c7e9c409c6ca80008c5dd01d44d1e',1,'Npgsql::NpgsqlError']]]
];
