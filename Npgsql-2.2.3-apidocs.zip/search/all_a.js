var searchData=
[
  ['major',['Major',['../class_npgsql_1_1_server_version.html#a85f3ce6612c012d1d5af926a6e0641d9',1,'Npgsql::ServerVersion']]],
  ['makeroomforbytes',['MakeRoomForBytes',['../class_npgsql_1_1_npgsql_copy_serializer.html#a8b5e17901c19ad8901fc520bc922af64',1,'Npgsql::NpgsqlCopySerializer']]],
  ['maxpoolsize',['MaxPoolSize',['../class_npgsql_1_1_npgsql_connection_string_builder.html#ad842ac35ed92e1bab5fde21abfbd479b',1,'Npgsql::NpgsqlConnectionStringBuilder']]],
  ['message',['Message',['../class_npgsql_1_1_npgsql_error.html#a3fdf2c2e58988ffb1641524b6934a499',1,'Npgsql.NpgsqlError.Message()'],['../class_npgsql_1_1_npgsql_error.html#a4839b846e4a8c8f3e44a461e393991e7a4c2a8fe7eaf24721cc7a9f0175115bd4',1,'Npgsql.NpgsqlError.Message()']]],
  ['minor',['Minor',['../class_npgsql_1_1_server_version.html#a556510fa92d0017aba21d42d2458ddf6',1,'Npgsql::ServerVersion']]],
  ['minpoolsize',['MinPoolSize',['../class_npgsql_1_1_npgsql_connection_string_builder.html#a9fa22a2efdfce176645727133245bcd2',1,'Npgsql::NpgsqlConnectionStringBuilder']]]
];
