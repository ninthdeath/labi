var searchData=
[
  ['read',['Read',['../class_npgsql_1_1_npgsql_copy_out.html#acc6a846bbdfeeae998fd25b82fdd6e36',1,'Npgsql::NpgsqlCopyOut']]],
  ['routine',['Routine',['../class_npgsql_1_1_npgsql_error.html#afc5d161b47c92ff3a914d58b4fbeb5da',1,'Npgsql.NpgsqlError.Routine()'],['../class_npgsql_1_1_npgsql_exception.html#a3d6517dd4aa4bca312b8e24b16faa93f',1,'Npgsql.NpgsqlException.Routine()']]]
];
