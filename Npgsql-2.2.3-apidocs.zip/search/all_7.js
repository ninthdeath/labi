var searchData=
[
  ['hasordinal',['HasOrdinal',['../class_npgsql_1_1_npgsql_data_reader.html#a003ca85adf3f9f3831a3a5e4f9ea96e3',1,'Npgsql::NpgsqlDataReader']]],
  ['hint',['Hint',['../class_npgsql_1_1_npgsql_error.html#a92fa74288670df57c50784b4ead9f5e6',1,'Npgsql.NpgsqlError.Hint()'],['../class_npgsql_1_1_npgsql_exception.html#a279996e7572c4031cb4ef65a66adfe8e',1,'Npgsql.NpgsqlException.Hint()'],['../class_npgsql_1_1_npgsql_error.html#a4839b846e4a8c8f3e44a461e393991e7ad11c7e9c409c6ca80008c5dd01d44d1e',1,'Npgsql.NpgsqlError.Hint()']]],
  ['host',['Host',['../class_npgsql_1_1_npgsql_connection.html#ad6638b9c1f616623ec20a4c4aa05b8dc',1,'Npgsql.NpgsqlConnection.Host()'],['../class_npgsql_1_1_npgsql_connection_string_builder.html#a6cac1e7072c7d01b41cd086862ee56b7',1,'Npgsql.NpgsqlConnectionStringBuilder.Host()']]]
];
