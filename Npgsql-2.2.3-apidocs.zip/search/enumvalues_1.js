var searchData=
[
  ['datatypename',['DataTypeName',['../class_npgsql_1_1_npgsql_error.html#a4839b846e4a8c8f3e44a461e393991e7a3fa1387be5a32decd7d9d2a23f83d62a',1,'Npgsql::NpgsqlError']]],
  ['debug',['Debug',['../namespace_npgsql.html#a012be6ba61a69f4a6b298eed8c6fd371aa603905470e2a5b8c13e96b579ef0dba',1,'Npgsql']]],
  ['detail',['Detail',['../class_npgsql_1_1_npgsql_error.html#a4839b846e4a8c8f3e44a461e393991e7aa254c25adc7d10d7e9c4889484f875a5',1,'Npgsql::NpgsqlError']]]
];
