var searchData=
[
  ['dispose',['Dispose',['../class_npgsql_1_1_npgsql_command.html#aee07b0d443110fe873de2133810912d7',1,'Npgsql.NpgsqlCommand.Dispose()'],['../class_npgsql_1_1_npgsql_connection.html#ae5193c6539c0e64f2bc7a0119bf66606',1,'Npgsql.NpgsqlConnection.Dispose()'],['../class_npgsql_1_1_npgsql_transaction.html#ac140dc0aa102b69a08ec7dca5a0b5636',1,'Npgsql.NpgsqlTransaction.Dispose()']]]
];
