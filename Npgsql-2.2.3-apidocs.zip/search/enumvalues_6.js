var searchData=
[
  ['message',['Message',['../class_npgsql_1_1_npgsql_error.html#a4839b846e4a8c8f3e44a461e393991e7a4c2a8fe7eaf24721cc7a9f0175115bd4',1,'Npgsql::NpgsqlError']]]
];
