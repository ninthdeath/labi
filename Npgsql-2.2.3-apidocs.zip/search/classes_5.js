var searchData=
[
  ['serverversion',['ServerVersion',['../class_npgsql_1_1_server_version.html',1,'Npgsql']]],
  ['sqlupdategenerator',['SqlUpdateGenerator',['../class_npgsql_1_1_sql_generators_1_1_sql_update_generator.html',1,'Npgsql::SqlGenerators']]],
  ['streamer',['Streamer',['../class_npgsql_1_1_row_reader_1_1_streamer.html',1,'Npgsql::RowReader']]],
  ['streamer_3c_20t_20_3e',['Streamer&lt; T &gt;',['../class_npgsql_1_1_row_reader_1_1_streamer_3_01_t_01_4.html',1,'Npgsql::RowReader']]]
];
