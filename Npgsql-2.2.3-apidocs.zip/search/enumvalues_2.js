var searchData=
[
  ['file',['File',['../class_npgsql_1_1_npgsql_error.html#a4839b846e4a8c8f3e44a461e393991e7a0b27918290ff5323bea1e3b78a9cf04e',1,'Npgsql::NpgsqlError']]]
];
